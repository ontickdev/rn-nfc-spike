
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'ontick',
  applicationName: 'spike',
  appUid: 'PcgywrrWyyNqWGRWnB',
  orgUid: '5e565a6a-b165-41ea-9668-b5f927bdb74c',
  deploymentUid: 'db6accf0-f259-4d7f-95da-aa1c1d81e3d1',
  serviceName: 'back-end',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.1.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'back-end-dev-androidDigitalAssetLinks', timeout: 6 };

try {
  const userHandler = require('./src/functions/androidDigitalAssetLinks.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}